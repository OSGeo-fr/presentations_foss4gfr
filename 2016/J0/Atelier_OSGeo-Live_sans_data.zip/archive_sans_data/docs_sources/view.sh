### script bash ###
# Ce petit script permet de générer une page html et un pdf à partir d'un fichier asciidoc.

# génération d'une page html
asciidoctor --trace -a linkcss OsGeo-live.adoc 

# génération d'un pdf (images trop grosses)
#a2x -f pdf OsGeo-live.adoc 


# génération d'un document tex
a2x -a lang=fr --format=tex OsGeo-live.adoc 

# génération d'un epub (à réaliser)
#a2x --fop OsGeo-live.adoc 

# génération d'une présentation au format html (non fonctionnel)
#asciidoc -b deckjs OsGeo-live.adoc
