<?php

# Connexion a la base postgis 'atelier'
try{
	$conn = new PDO('pgsql:host=localhost;dbname=atelier',
	'postgres','postgres');
}
catch(Exception $e){
	die('Erreur: '.$e->getMessage());
}

# Creation de la requete SQL SELECT  et passage de la geometrie dans un 
#format geojson
$sql = 'SELECT *, public.ST_AsGeoJSON(public.ST_Transform((geom),4326),6) 
		AS geojson FROM arbres_remarquables';
/*
* If bbox variable is set, only return records that are within  bounding box
* bbox should be a string in the form of 'southwest_lng,southwest_lat,
* northeast_lng,northeast_lat'
* Leaflet: map.getBounds().toBBoxString()
*/
if (isset($_GET['bbox'])) {
    $bbox = explode(',', $_GET['bbox']);
    $sql = $sql . ' WHERE public.ST_Transform(geom, 4326) 
    && public.ST_SetSRID(public.ST_MakeBox2D(public.ST_Point('
    .$bbox[0].', '.$bbox[1].'), public.ST_Point('.$bbox[2].', 
    '.$bbox[3].')),4326);';
}
# Essaie la connexion ou renvoie un message d'erreur
$rs = $conn->query($sql);
if (!$rs) {
    echo 'An SQL error occured.';
    exit;
}
# Creation d'un objet geojson qui collectera tous les entites extraites
$geojson = array(
   'type'      => 'FeatureCollection',
   'features'  => array()
);
# Boucle qui parcout les enregistrements fournis par la requete
# et les transforme en entite geojson
while ($row = $rs->fetch(PDO::FETCH_ASSOC)) {
    $properties = $row;
    # supprime les champs geojson et geometry des proprietes
    unset($properties['geojson']);
    unset($properties['geom']);
    $feature = array(
         'type' => 'Feature',
         'geometry' => json_decode($row['geojson'], true),
         'properties' => $properties
    );
    # Ajoutes les entites dans l'objet charge de les collecter
    array_push($geojson['features'], $feature);
}
header('Content-type: application/json');
echo json_encode($geojson, JSON_NUMERIC_CHECK);
$conn = NULL;
?>
