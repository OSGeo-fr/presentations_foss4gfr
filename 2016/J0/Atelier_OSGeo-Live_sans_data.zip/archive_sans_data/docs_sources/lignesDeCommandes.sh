#!/bin/bash
### Bash ###

## insertion d'un fichier geojson dans une base postgis
ogr2ogr -f "PostgreSQL" PG:"dbname=atelier user=postgres" \
"arbres-remarquables.geojson" -nln arbres_remarquables_json \
-append -t_srs "EPSG:2154"

## Leaflet copie de fichier dans le répertoire du serveur serveur
# se placer dans le dossier leaflet avec le gestionnaire de fichier et 
#appuyer sur F4 pour lancer un terminal depuis le dossier

sudo cp arbres_rem.php /var/www/html/
sudo cp atelier.php /var/www/html/
sudo cp leaf-green.png /var/www/html/
sudo cp leaf-shadow.png /var/www/html/

### Requêtes SQL ###

SELECT * FROM arbres_remarquables;

SELECT * FROM arbres_remarquables, mos2012_11_25m WHERE code11 = 1  
AND ST_WITHIN(arbres_remarquables.geom,mos2012_11_25m.geom) ;

SELECT * FROM arbres_remarquables 
WHERE arbres_remarquables.id NOT IN 
(SELECT id FROM arbres_remarquables, mos2012_11_25m WHERE code11 = 1  
AND ST_intersects(arbres_remarquables.geom,mos2012_11_25m.geom)) ;

CREATE VIEW arbres_rem_hors_forets AS SELECT * 
FROM arbres_remarquables 
WHERE arbres_remarquables.id NOT IN 
(SELECT id FROM arbres_remarquables, mos2012_11_25m WHERE code11 = 1  
AND ST_intersects(arbres_remarquables.geom,mos2012_11_25m.geom)) ;

CREATE OR REPLACE VIEW arbres_rem_hors_forets AS 
SELECT * FROM arbres_remarquables WHERE arbres_remarquables.id 
NOT IN (SELECT id FROM arbres_remarquables, mos2012_11_25m 
WHERE code11 = 1  AND 
ST_intersects(arbres_remarquables.geom,mos2012_11_25m.geom)) 
AND essence like 'Orme';
