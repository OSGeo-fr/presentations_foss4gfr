#!/bin/bash

#----------------------------------------------------------------------
# Objet	 : 	Traiter les fichiers LANDSAT8
# Auteur : 	Nicolas Roelandt
# Date   : 	30/04/2016
# Usage	 :	Copier et executer dans le répertoire decompresse				
# Licence:	"THE BEER-WARE LICENSE" (Revision 42)		
#----------------------------------------------------------------------

## Recuperation du nom du dossier et du fichier
dossier=${PWD##*/}

### Personnalisation au demarrage du script
## Parametre a modifier en dernier ligne du script
#echo "Quel nom souhaitez-vous donner au fichier ?"
#read nom


## Reprojection des images en webMercator Spherique (EPSG:3857)
for BAND in {4,3,2}; do
	fichier=$dossier"_B"$BAND".TIF"
	gdalwarp -t_srs EPSG:3857 $fichier $BAND-projected.tif;
done

## Fusion des 3 images en une seule
convert -combine {4,3,2}-projected.tif RGB.tif

## Correction du contrast et des gamma des canaux Bleu et Rouge
convert -channel B -gamma 0.925 -channel R -gamma 1.03 \
-channel RGB -sigmoidal-contrast 50x16% RGB.tif RGB-corrected.tif

## Passage en codage 8 bit
convert -depth 8 RGB-corrected.tif RGB-corrected-8bit.tif

## Recuperation du georeferencement des images d'origine
listgeo -tfw 4-projected.tif

## Creation du fichier de georeferencement pour notre image 8bit
mv 4-projected.tfw RGB-corrected-8bit.tfw

## Ajout du systeme de reference spatial (SRS) au fichier tif avec GDAL
gdal_edit.py -a_srs EPSG:3857 RGB-corrected-8bit.tif

## Changement du nom du fichier
## Remplacer SeineEtMarne par $nom pour un nom personnalise
## ou par $dossier pour garder le nom du dossier
mv RGB-corrected-8bit.tif SeineEtMarne-projected.tif
