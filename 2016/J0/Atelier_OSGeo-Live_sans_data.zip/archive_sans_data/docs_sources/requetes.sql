-- pour décommenter une ligne, il faut enlever les deuxtraits d'union en début de ligne.
SELECT * FROM arbres_remarquables; 

SELECT * FROM arbres_remarquables, mos2012_11_25m WHERE code11 = 1  AND ST_WITHIN(arbres_remarquables.geom,mos2012_11_25m.geom) ; 

SELECT * FROM arbres_remarquables, mos2012_11_25m WHERE code11 = 1  AND ST_intersects(arbres_remarquables.geom,mos2012_11_25m.geom);

SELECT * FROM arbres_remarquables WHERE arbres_remarquables.id NOT IN (SELECT id FROM arbres_remarquables, mos2012_11_25m WHERE code11 = 1  AND ST_intersects(arbres_remarquables.geom,mos2012_11_25m.geom)) ;

CREATE VIEW arbres_hors_forets  AS SELECT * FROM arbres_remarquables WHERE arbres_remarquables.id NOT IN (SELECT id FROM arbres_remarquables, mos2012_11_25m WHERE code11 = 1  AND ST_intersects(arbres_remarquables.geom,mos2012_11_25m.geom)) ;
