﻿# -*- coding: utf-8 -*-
#----------------------------------------------------------------------
# Nom    : script.py
# Objet  : Modifier et insérer des lignes dans un fichier .tex
# Auteur : Nicolas Roelandt
# Date   : 29/04/2016			Licence: LPRAB V1-2009
#----------------------------------------------------------------------

# gestion de l'argument
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("nom", help="nom du fichier")
args = parser.parse_args()

#fichier en entree
fichier = open(args.nom +".tex","r")
#fichier en sortie
sortie = open(args.nom+"_final.tex","w")

for ligne in fichier:
	## changement de la classe de document
	if ligne == "\documentclass{article}\n":
		# Taille police: 12 pt, format A4, recto-verso
		# ajout du package moreverb pour l'inclusion de fichier de code
		sortie.write("\documentclass[12pt,a4paper,twoside]{article}%\n \
		%%\n\usepackage{moreverb}%\n%%\n ")
		 
	## remplacement de la commande \maketitle par l'insertion d'une
	# page de garde externe
	# changement des marges gauches pages paires: evensidemargin
	elif ligne == "\maketitle\n":
		sortie.write("\n%%\n \input{couv_support}% \n%%\n\
		\setlength{\evensidemargin}{1cm}%\n")

	## Ajout des annexes
	elif ligne == "\section{Annexes}\n":
		sortie.write(u"\\newpage% \n %% \n\\appendix% \n %% \
		\n\section{Annexes}%\n %% \
		 \n\\renewcommand{\\thesection}{\Alph{section}}% \n %% \
		 \n\subsection{Rappel des lignes de commandes}% \n %% \
		 \n\listinginput[5]{1}{Data/lignesDeCommandes.sh}% \n %% \n\
		 \n\subsection{Atelier.html}% \n %% \
		\n\listinginput[5]{1}{../docs_sources/imprim_atelier.html}% \n %% \n\
		\n\subsection{arbres\_rem.php}% \n %% \
		\n\listinginput[5]{1}{../docs_sources/imprim_arbres_rem.php}% \n %% \n")
	else:
		sortie.write(ligne)

## Fermeture des fichiers
fichier.close()
sortie.close()
