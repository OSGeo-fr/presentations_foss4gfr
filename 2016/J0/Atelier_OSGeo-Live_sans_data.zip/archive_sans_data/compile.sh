#!/bin/bash
#----------------------------------------------------------------------
# Objet  : 	Génération des fichier html et pdf à partir d'un document
# 			asciidoc
# Auteur : 	Nicolas Roelandt
# Date   : 	26/04/2016
# Licence:	"THE BEER-WARE LICENSE" (Revision 42)
#----------------------------------------------------------------------

# nécessite asciidoctor et RubyOnRails pour être fonctionnel :S
# Pandoc semble plus simple d'installation et d'utilisation


### Mesure de l'heure de démarrage du script
start=$(date +%s.%N) # temps de départ

## création du dossier nécessaire à la compilation
mkdir build

### insertion des fichiers sources dans le répertoire courant
cp docs_sources/*.tex $PWD 	# page de garde
cp docs_sources/*.py $PWD	# script python 

## Déclaration du nom de fichier source à traiter
nom="OsGeo-live"  ## Nom du fichier à traiter (sans extension).


# génération d'une page html
asciidoctor --trace -a linkcss $nom".adoc" 

# génération d'un pdf (couverture peu engageante)
#a2x -f pdf OsGeo-live.adoc 

# génération d'un epub (non fonctionnel)
#(à réaliser voir: http://kaczanowscy.pl/tomek/category/tool/asciidoc )
#a2x --fop OsGeo-live.adoc 

# génération d'une présentation au format html (non fonctionnel)
#asciidoc -b deckjs OsGeo-live.adoc

# génération d'un document tex
a2x -a lang=fr --format=tex $nom".adoc" 

## Insertion des lignes incluant la page de garde,
## les annexes et les fichiers avec les packages latex nécessaires
## l'utilisation de bash générait des erreurs, script python ok
python script.py $nom
	
## compilation de la présentation à partir du fichier presentation.txt
## des fois qu'elle ait été changée entre temps
#asciidoc --backend slidy presentation.txt

# Compilation sous Unix/Linux
## à partir du blog de Dorian Depriester

## Première compilation avant bibliographie
pdflatex -output-directory=build/ -interaction=nonstopmode \
 $nom"_final.tex" 

## Création du glossaire (non utilisé)
#makeglossaries  Main

##Génération de la bibliographie
#cd build/
#for i in *.aux
#do
#  if [ "$i" == $nom"_final.aux" ] ;then
#    continue;
#  fi
#  bibtex ${i%.*}
#done
#cd ..
### compilation nécessaire si utilisation de la bibliographie
#pdflatex -output-directory=build/ -interaction=nonstopmode \
 $nom"_final.tex" 

#Double compilation finale (génération de la table des matières 
#et des références si besoin)
pdflatex -output-directory=build/ -interaction=nonstopmode \
 $nom"_final.tex" 
 
## Double compilation de la présentation
pdflatex -output-directory=build/ -interaction=nonstopmode \
 $nom"_presentation.tex" 
pdflatex -output-directory=build/ -interaction=nonstopmode \
 $nom"_presentation.tex" 
 
### Nettoyage du dossier
## déplacement des pdfs générés dans le répertoire principal 
mv build/*.pdf $PWD	
# suppression des fichiers .tex générés
rm *.tex 			 
rm *.py
# vidange du dossier build 
#(à commenter pour garder le fichier .log en cas d'erreurs)
rm -r build/* 		
# suppression du dossier build
rmdir build/  		

#################################################
### Mesure du temps d'exécution
echo ""
echo "#####################################" 
echo ""
dur=$(echo "$(date +%s.%N) - $start" | bc)

echo "Temps d'execution: $dur secondes" 
